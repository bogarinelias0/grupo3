from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from posteo import views
from posteo.views import (
    posteoListViews,
    posteoDetailViews,
    posteoCreateViews,
    posteoUpdateViews,
    posteoDeleteViews
    )

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('', posteoListViews.as_views(), name='list'),
    path('<slug>', posteoDetailViews.as_views(), name='detail'),
    path('create/', posteoCreateViews.as_views(), name='create'),
    path('<slug/update/>', posteoUpdateViews.as_views(), name='update'),
    path('<slug>/delete/', posteoDeleteViews.as_views(), name='delete'),
    path('post/', views.lista_post)

]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.MEDIA_ROOT)
