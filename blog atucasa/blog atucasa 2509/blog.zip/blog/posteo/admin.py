from django.contrib import admin


from.models import posteo, posteoview, Coment, like, dislike, User

admin.site.register(posteo)
admin.site.register(posteoview)
admin.site.register(Coment)
admin.site.register(like)
admin.site.register(dislike)
admin.site.register(User)
