from django.apps import AppConfig


class PosteoConfig(AppConfig):
    name = 'posteo'
