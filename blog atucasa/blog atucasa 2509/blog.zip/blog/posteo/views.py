from django.shortcuts import render, HttpResponse
from django.views.generic import ListView, DetailView,CreateView, UpdateView, DeleteView
from .models import posteo, posteoview, Coment, like, dislike

class posteoListViews(ListView):
    model = posteo

class posteoDetailViews(DetailViews):
    model = posteo
    
class posteoCreateViews(CreateViews):
    model = posteo

class posteoUpdateViews(UpdateViews):
    model = posteo
    fields = (
    'title',
    'content',
    'thumbmail',
    'autor', 
    'slug'
    )

class posteoDeleteViews(DeleteView):
    model = posteo

def lista_post(request):
    return HttpResponse("post")

